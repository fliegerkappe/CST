#! /bin/bash

# use this script to see if any of the CST scripts are erroring

set -e #Stop on error (optional)

scripts=(
"./rhel-9-ac10.sh"
"./rhel-9-ac11.sh"
"./rhel-9-ac12.sh"
"./rhel-9-ac17.sh"
"./rhel-9-ac18.sh"
"./rhel-9-ac2.sh"
"./rhel-9-ac3.sh"
"./rhel-9-ac6.sh"
"./rhel-9-ac7.sh"
"./rhel-9-ac8.sh"
"./rhel-9-au12.sh"
"./rhel-9-au14.sh"
"./rhel-9-au3.sh"
"./rhel-9-au4.sh"
"./rhel-9-au5.sh"
"./rhel-9-au6.sh"
"./rhel-9-au7.sh"
"./rhel-9-au8.sh"
"./rhel-9-au9.sh"
"./rhel-9-cm14.sh"
"./rhel-9-cm3.sh"
"./rhel-9-cm5.sh"
"./rhel-9-cm6.sh"
"./rhel-9-cm7.sh"
"./rhel-9-ia11.sh"
"./rhel-9-ia2.sh"
"./rhel-9-ia3.sh"
"./rhel-9-ia5.sh"
"./rhel-9-ia7.sh"
"./rhel-9-ma4.sh"
"./rhel-9-sc10.sh"
"./rhel-9-sc13.sh"
"./rhel-9-sc24.sh"
"./rhel-9-sc28.sh"
"./rhel-9-sc2.sh"
"./rhel-9-sc3.sh"
"./rhel-9-sc4.sh"
"./rhel-9-sc5.sh"
"./rhel-9-sc8.sh"
"./rhel-9-si11.sh"
"./rhel-9-si16.sh"
"./rhel-9-si2.sh"
"./rhel-9-si6.sh"
)

for script in ${scripts[@]}
do
  if ! "$script"; then
    echo  
    echo "Error: $script failed with exit code $?"
    echo
    exit 1
  fi
done
echo
echo "All scripts completed successfully."
echo

exit
