#! /bin/bash

# script: getresults.sh

# Used to collect just the "RESULT" and pass/fail status of each "RULE ID".

# Usage: [your-host scripts]# ./getresults.sh ../reports/[filename]-full.txt

IFS='
'

NORMAL=`echo "\e[0m"`           # normal font color

if [[ -f $1 ]]
then
  report="$(cat $1)"
  for line in ${report[@]}
  do
    if [[ $line =~ ("------------"|"RULE ID:"|"RESULT:") ]]
    then
      echo $line
    elif [[ $line =~ ("PASSED"|"FAILED"|"N/A"|"VERIFY") ]]
    then
      status="$(echo $line | awk -F, '{print $8}')"
      echo "STATUS:   $status"
    fi
  done
else
  echo "$1 not found"
fi

echo -e "${NORMAL}"

exit

