#! /bin/bash

# script: removecolors.sh

# Used to strip out all font color substitutions in a report file

# Usage: [your-host scripts]# ./removecolors.sh ../reports/[filename]-brief.txt (for example)

IFS='
'

NORMAL=`echo "\e[0m"`           # normal font color

if [[ -f $1 ]]
then
    # remove colors from the csv file
    sed -i 's/[[:cntrl:]]\[0m//g' $1
    sed -i 's/[[:cntrl:]]\[31\;1m//g' $1
    sed -i 's/[[:cntrl:]]\[32\;1m//g' $1
    sed -i 's/[[:cntrl:]]\[0\;1m//g' $1
    sed -i 's/[[:cntrl:]]\[33\;1\;35m//g' $1
    sed -i 's/[[:cntrl:]]\[93\;1m//g' $1
    sed -i 's/[[:cntrl:]]\[11\;1\;44m//g' $1
else
  echo "$1 not found"
fi

echo -e "${NORMAL}"

exit

